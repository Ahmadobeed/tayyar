const crypto=require('crypto');
const E=process.env,BASE=(E.TURSO_DATABASE_URL||'').replace(/^libsql:/,'https:'),TOK=E.TURSO_AUTH_TOKEN,SEC=E.SESSION_SECRET||'';
const A0={u:E.ADMIN_USER||'admin',p:E.ADMIN_PASS||'Admin@2026'};
async function q(list){
 const rq=list.map(([sql,args])=>({type:'execute',stmt:{sql,args:(args||[]).map(v=>v==null?{type:'null'}:{type:'text',value:String(v)})}}));rq.push({type:'close'});
 const r=await fetch(BASE+'/v2/pipeline',{method:'POST',headers:{Authorization:'Bearer '+TOK,'Content-Type':'application/json'},body:JSON.stringify({requests:rq})});
 const j=await r.json();if(!r.ok)throw new Error(JSON.stringify(j).slice(0,300));
 return j.results.slice(0,-1).map(x=>{if(x.type!=='ok')throw new Error(JSON.stringify(x.error||x).slice(0,300));const s=x.response.result;return s.rows.map(w=>Object.fromEntries(s.cols.map((c,i)=>[c.name,w[i].type==='null'?null:w[i].value])))})}
const sig=b=>crypto.createHmac('sha256',SEC).update(b).digest('base64url');
const sign=p=>{const b=Buffer.from(JSON.stringify(p)).toString('base64url');return b+'.'+sig(b)};
const verify=t=>{try{const [b,s]=String(t).split('.'),e=sig(b);if(!SEC||!s||s.length!==e.length||!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(e)))return null;const p=JSON.parse(Buffer.from(b,'base64url'));return p.exp>Date.now()?p:null}catch(e){return null}};
exports.handler=async ev=>{
 const R=(c,o)=>({statusCode:c,headers:{'Content-Type':'application/json'},body:JSON.stringify(o)});
 if(ev.httpMethod!=='POST')return R(405,{e:'method'});
 try{
  if(!BASE||!TOK||!SEC)return R(500,{e:'متغيرات البيئة ناقصة في Netlify'});
  await q([['CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,kind TEXT,dept TEXT,json TEXT)']]);
  const b=JSON.parse(ev.body||'{}');
  if(b.a==='login'){
   const [rows]=await q([["SELECT kind,json FROM items WHERE kind IN ('cfg','dept')"]]);
   let ad=A0;const c=rows.find(x=>x.kind==='cfg');if(c){const j=JSON.parse(c.json);if(j.admin)ad=j.admin}
   const exp=Date.now()+12*36e5;
   if(b.u===ad.u&&b.p===ad.p)return R(200,{t:sign({role:'admin',exp}),me:{role:'admin'}});
   for(const x of rows.filter(x=>x.kind==='dept')){const d=JSON.parse(x.json);if(d.user===b.u&&d.pass===b.p)return R(200,{t:sign({role:'dept',dept:d.id,exp}),me:{role:'dept',dept:d.id}})}
   return R(401,{e:'bad'})}
  const me=verify(b.t);if(!me)return R(401,{e:'auth'});
  const adm=me.role==='admin';
  if(b.a==='pull'){
   const [rows]=await q(adm?[['SELECT id,kind,dept,json FROM items ORDER BY rowid']]:[["SELECT id,kind,dept,json FROM items WHERE kind IN ('cfg','post') OR (kind='dept' AND id=?1) OR (kind IN ('emp','req','nt') AND dept=?1) ORDER BY rowid",[me.dept]]]);
   const items=rows.map(x=>{if(adm)return x;const j=JSON.parse(x.json);if(x.kind==='cfg')delete j.admin;if(x.kind==='dept')delete j.pass;return{...x,json:JSON.stringify(j)}});
   const empty=!rows.length;if(adm&&!rows.some(x=>x.kind==='cfg'))items.unshift({id:'cfg',kind:'cfg',dept:'',json:JSON.stringify({admin:A0})});
   const h=crypto.createHash('md5').update(JSON.stringify(items)).digest('hex');
   return R(200,b.h===h?{same:1}:{h,empty,items})}
  if(b.a==='push'){
   const up=Array.isArray(b.up)?b.up:[],del=Array.isArray(b.del)?b.del:[],K=['cfg','dept','emp','req','post','nt'];
   if(up.some(x=>!x||!K.includes(x.kind)||typeof x.id!=='string'||typeof x.json!=='string')||del.some(x=>typeof x!=='string'))return R(400,{e:'bad'});
   if(!adm){
    const ids=[...up.map(x=>x.id),...del],ex={};
    if(ids.length){const [r]=await q([[`SELECT id,kind,dept FROM items WHERE id IN (${ids.map(()=>'?').join(',')})`,ids]]);r.forEach(x=>ex[x.id]=x)}
    for(const x of up){const e=ex[x.id];let ok=false;
     if(x.kind==='req')ok=!e&&x.dept===me.dept;
     else if(x.kind==='nt')ok=(x.dept==='a'&&!e)||(x.dept===me.dept&&(!e||e.dept===me.dept));
     if(!ok)return R(403,{e:'ممنوع'})}
    for(const id of del){const e=ex[id];if(!(e&&e.kind==='nt'&&e.dept===me.dept))return R(403,{e:'ممنوع'})}
    up.forEach(x=>{if(x.kind==='req'){const j=JSON.parse(x.json);j.st='pending';j.dept=me.dept;x.json=JSON.stringify(j)}})}
   const st=[['BEGIN']];
   up.forEach(x=>st.push(['INSERT INTO items(id,kind,dept,json) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET kind=excluded.kind,dept=excluded.dept,json=excluded.json',[x.id,x.kind,x.dept||'',x.json]]));
   del.forEach(id=>st.push(['DELETE FROM items WHERE id=?',[id]]));
   st.push(['COMMIT']);await q(st);return R(200,{ok:1})}
  return R(400,{e:'bad action'});
 }catch(e){return R(500,{e:String(e.message||e)})}};
